package com.corhuila.Backendparcial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendparcialApplicationTests {

	@Test
	void contextLoads() {
	}

}
